<?php
  $apiKey = getenv('APIKEY');
  var_dump($apiKey); // Ini akan menampilkan nilai atau null jika tidak ada