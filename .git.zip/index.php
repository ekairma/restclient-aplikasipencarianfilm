<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Movie Finder</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h1>🎬 Movie / Film Finder</h1>
<?php
 // Contoh teks dinamis sederhana
 $judul = "Selamat datang di Movie Finder!";
 echo "<h2>$judul</h2>";
 ?>
<div class="menu">
    <a href="laman-judulfilm.php">Cari Film Berdasarkan Judul</a>

</div>

</body>
</html>