<?php include "api.php"; ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cari Film Berdasarkan Judul</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<h2>🔍 Cari Film Berdasarkan Judul</h2>

<form method="GET">
    <input type="text" name="judul" placeholder="Masukkan Judul Film" required>
    <button type="submit">Cari</button>
</form>

<?php
if (isset($_GET['judul'])) {
    $judul = urlencode($_GET['judul']);
    $url = "http://www.omdbapi.com/?i=tt3896198&apikey=a938f6aa&s=$judul";

    $data = callAPI($url);

    if (!empty($data["Search"])) {
        echo "<div class='result'><h3>Hasil Pencarian:</h3>";
        foreach ($data["Search"] as $film) {
            echo "<p><b>{$film['Title']}</b> ({$film['Year']}) — <i>{$film['Type']}</i></p>";
        }
        echo "</div>";
    } else {
        echo "<p>Tidak ditemukan.</p>";
    }
}
?>

</body>
</html>
